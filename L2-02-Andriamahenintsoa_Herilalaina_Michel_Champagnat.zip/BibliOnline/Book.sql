CREATE TABLE book(
    author VARCHAR(255) not null,
    nom VARCHAR(255) not null,
    typ VARCHAR(255) CHECK (typ IN ('Roman', 'Avanture', 'Fiction')),
    dispo BOOLEAN DEFAULT TRUE
);