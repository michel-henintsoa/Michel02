
public class Book {
	private String author;
	private String name;
	private String typ;
	private boolean disp;
	public Book() {
		
	}
	public void setAttribute(String _a, String _n, String _t, boolean _d) {
		this.author=_a;
		this.name=_n;
		this.typ=_t;
		this.disp=_d;
	}
	public String getAuthor() {
		return this.author;
	}
	public String getName() {
		return this.name;
		
	}
	public String getTyp() {
		return this.typ;
	}
	public boolean isDispo() {
		return this.disp;
	}
	
	
}
