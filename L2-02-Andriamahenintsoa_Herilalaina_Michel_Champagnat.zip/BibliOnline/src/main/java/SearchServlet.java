import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class SearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String term = request.getParameter("term");
        
        if (term != null && !term.isEmpty()) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/book", "mit","123456")) {
                
                String sql = "SELECT * FROM book WHERE "+request.getParameter("search")+" LIKE ?";
                try (PreparedStatement statement = conn.prepareStatement(sql)) {
                    statement.setString(1, "%" + term + "%");
                    try (ResultSet resultSet = statement.executeQuery()) {
                        PrintWriter out = response.getWriter();
                        out.println("<html><body>");
                        out.println("<h2>Résultats de la recherche pour : " + term + "</h2>");
                        out.println("<ul>");
                        while (resultSet.next()) {
                            out.println("<li>" + resultSet.getString(request.getParameter("search")) + "</li>");
                        }
                        out.println("</ul>");
                        out.println("</body></html>");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new ServletException("Database access error", e);
            }
        } else {
            response.getWriter().println("Veuillez fournir un terme de recherche.");
        }
    }
}

