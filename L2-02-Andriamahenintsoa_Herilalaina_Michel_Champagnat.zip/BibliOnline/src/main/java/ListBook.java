

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.beans.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Servlet implementation class ListBook
 */
public class ListBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		Connection conn=null;
		Statement state=null;
        ResultSet resultSet = null;
        ArrayList<Book> lbook=new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/book", "mit","123456");
			state=(Statement) conn.createStatement();
			String sqlQuery = "SELECT * FROM nom_de_la_table";
            resultSet = ((java.sql.Statement) state).executeQuery(sqlQuery);
            while (resultSet.next()) {
            	Book b=new Book();
                
            	b.setAttribute(resultSet.getString("author"), resultSet.getString("nom"), resultSet.getString("typ"), resultSet.getBoolean("dispo"));
                lbook.add(b);
            }
            request.setAttribute("list", lbook.toArray());
            request.getRequestDispatcher("/BibliOnline/List.jsp").forward(request, response);
		}catch (ClassNotFoundException e) {
            System.out.println("Erreur de connexion à la base de données : " + e.getMessage());
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
