
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class BookAvailabilityServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String bookName = request.getParameter("nom");
        
        
        if (bookName != null && !bookName.isEmpty()) {
           
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/book", "mit","123456")) {
               
                String sql = "SELECT COUNT(*) FROM book WHERE nom = ? AND dispo = true";
                try (PreparedStatement statement = conn.prepareStatement(sql)) {
                    statement.setString(1, bookName);
                    try (ResultSet resultSet = statement.executeQuery()) {
                      
                        resultSet.next();
                        int count = resultSet.getInt(1);
                        
                        
                        PrintWriter out = response.getWriter();
                        if (count > 0) {
                            out.println("Le livre \"" + bookName + "\" est disponible.");
                        } else {
                            out.println("Le livre \"" + bookName + "\" n'est pas disponible.");
                        }
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new ServletException("Database access error", e);
            }
        } else {
          
            response.getWriter().println("Veuillez fournir le nom d'un livre.");
        }
    }
}
