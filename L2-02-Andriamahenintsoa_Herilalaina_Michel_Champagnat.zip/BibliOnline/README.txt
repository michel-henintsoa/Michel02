L'arboressence est equivalent à tout web application

créer un utilisateur mysql dont le nom est "mit" et le mot de passe est "123456" accompagner d'une base de donnée sous le nom de book
la structure de la base de donnée est dans BibliOnline sous le nom de  Book.sql

