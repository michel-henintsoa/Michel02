<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ouverture BD</title>
</head>
<body>
    <?php
        session_start();
        $_SESSION["listbook"];
        $sql=mysqli_connect("localhost", "mit", "123456", "book", 3306) or die("Base de donnée introuvable");
        mysqli_select_db($sql, "book") or die("ERR");

        $query=mysqli_query($sql, "SELECT * FROM book");
        $list=[];
        while($line=mysqli_fetch_assoc($query)){
            $row=array($line["author"], $line["nom"], $line["typ"], $line["dispo"]);
            $list[]=$row;
        }
        mysqli_close($sql);
        $_SESSION["listbook"]=$list;
        header("Location: affichageList.php");
    ?>
</body>
</html>