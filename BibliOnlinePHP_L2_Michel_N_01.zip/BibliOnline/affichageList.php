<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listage des livre</title>
</head>
<body>
    <table style="border-collapse:collapse; border: 1px solid black">
		<tr>
			<th>
				Auteur
			</th>
			<th>
				Nom
			</th>
			<th>
				Type
			</th>
			<th>
				Disponibilité
			</th>
		</tr>
    <?php
        session_start();
        $_SESSION["listbook"];

        foreach($_SESSION["listbook"] as $elt){
            echo "
                <tr>
                <td>
                    $elt[0]
                </td>
                <td>
                    $elt[1]
                </td>
                <td>
                    $elt[2]
                </td>
                <td>
                    $elt[3]
                </td>
                <td>
                    <a href=availability.php?nom=".$elt[1].">voir</a>
                </td>
                </tr>

                ";
        }
    ?>
    </table>
    Recherche d'occurence :
	<form action="search.php" method="get">
		<input type="text" name="term" placeholder="Terme rechercher">
            <select name="search">
            	<option value="author">Auteur</option>
            	<option value="nom">Nom du livre</option>
            	<option value="typ">Genre du livre</option>
            </select>
        <input type="submit">
	</form><br>
</body>
</html>