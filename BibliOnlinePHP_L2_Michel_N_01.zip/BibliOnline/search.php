<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Résultat de recherche</title>
</head>
<body>
    <table style="border-collapse:collapse; border: 1px solid black">
		<tr>
			<th>
				Auteur
			</th>
			<th>
				Nom
			</th>
			<th>
				Type
			</th>
			<th>
				Disponibilité
			</th>
		</tr>
    <?php
        $term=$_GET["term"];
        $search=$_GET["search"];
        

        if(isset($term)){
            $sql=mysqli_connect("localhost", "mit", "123456", "book", 3306) or die("Base de donnée introuvable");
            mysqli_select_db($sql, "book") or die("ERR");
            
            $query=mysqli_query($sql, "SELECT * FROM book WHERE ".$search." LIKE '%".$term."%';");

            while($line=mysqli_fetch_assoc($query)){
                echo "
                    <tr>
                <td>".
                $line["author"]
                ."</td>
                <td>".
                $line["nom"]
                ."</td>
                <td>".
                $line["typ"]
                ."</td>
                <td>".
                $line["dispo"]
                ."</td>
                </tr>
                ";
            }

            mysqli_close($sql);
        }
        else{
            echo "<p>Veuillez fournir un terme de recherche.</p>";

            header("Location: affichageList.php");
        }
    ?>
    </table>
</body>
</html>