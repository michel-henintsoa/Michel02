Pour s'assurer que ce code marche bien:
    _créer un user mit dont le mot de passe est 123456
    _créer une base de donnée au nom de book
    _il faut faire un sourcer leh Book.sql:
    ->mysql -u mit -p
    ->(Entrer le mot de passe)
    ->use book;
    ->source /lien/vers/Book.sql;

