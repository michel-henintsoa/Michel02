<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertion base de donnée</title>
</head>
<body>
    <?php
    // Correction de la connexion à la base de données
    $sql = mysqli_connect("localhost", "mit", "123456", "book", 3306) or die("Base de donnée introuvable");
    
    // Correction de la requête d'insertion
    mysqli_query($sql," INSERT INTO book (author, nom, typ, dispo) VALUES ('zah', 'zahy', 'Autre', 1)") or die("Erreur lors de l'insertion : " . mysqli_error($sql));
    mysqli_query($sql, "INSERT INTO book (author, nom, typ, dispo) VALUES ('Andry Andraina', 'Mitaraina ny tany', 'Autre', 1);");

    mysqli_close($sql);

    // Redirection avant tout affichage de contenu
    header("Location: listBook.php");
    exit; // Ajout d'un exit pour s'assurer que le script s'arrête après la redirection
?>

</body>
</html>