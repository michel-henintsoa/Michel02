<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disponibilité</title>
</head>
<body>
    <?php
        $bookname=$_GET["nom"];

        $sql=mysqli_connect("localhost", "mit", "123456", "3306") or die("Base de donnée introuvable");
        mysqli_select_db($sql, "book") or die("ERR");

        $query=mysqli_query($sql, "SELECT * FROM book WHERE nom=".$bookname." AND dispo=true");
        $count=0;
        while($line=mysqli_fetch_row($query)){
            $count++;
        }
        if($count>0){
            echo "Le livre \"" . $bookName . "\" est disponible.";
        }
        else{
            echo "Le livre \"" . $bookName . "\" n'est pas disponible.";
        }

    ?>
</body>
</html>